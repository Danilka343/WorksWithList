package Lesson_2;

public interface Mooving {

    void move(); //default interface methods.
    void run();
}
