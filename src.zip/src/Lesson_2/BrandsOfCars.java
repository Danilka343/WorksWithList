package Lesson_2;

public interface BrandsOfCars {
    String[] Brands = {"BMW", "Mercedes", "Tesla", "Audi", "KIA", "Nissan", "Opel","Porsche","Toyota", "Rolls-Royce"};
    String getRandomOfBrands(); //method that we declare in the class.
}
