package Lesson_3.data;

public interface RandomOfNameAndAuthor {
    String getRandomOfBookName();
    String getRandomOfAuthor();
}
